package com.example.simplecalculator_4nov_dhivya;

import android.widget.Toast;

import java.util.ArrayList;
import android.util.Log;

public class Calculate {
 // Creating  an arraylist
 ArrayList<String> array1 = new ArrayList<String>();
 //create an object of the class Calculate
Calculate calc =new  Calculate();
 public void push(String value) {
  //Initializing the values
  array1.add(value);
  Log.d("SimpleCalculator_4Nov_Dhivya", "Display the array list");

 }

        int i  = 0;

    {
        int n1 = 0;
        int n2 = 0;
        int result = 0;
        char op;
        boolean moreoop = false;

        //Check if the entered string is an number or operator

        if ((array1.get(i) == "+") || (array1.get(i) == "-") || (array1.get(i) == "*") || (array1.get(i) == "/")) {
            if (moreoop) {
                //convert the char from string to  a char is using the CharAt(index)
                op = array1.get(i).charAt(i);
                n1 = Integer.parseInt((String) array1.get(i));
                n2 = Integer.parseInt((String) array1.get(i + 1));
                result = calc.splcalculate(n1, n2, op);
                n1 = result;
                i = i + 2;
                moreoop = true;
            } else {
                i++;
            }
        }
    }
     public int splcalculate (int n1,int n2,char op) {
        //int add, sub, mul, div;
        int res = 0;
        switch (op) {
            case '+':
              res = n1 + n2;
                break;
            case '-':
               res = n1 - n2;
                break;
            case '*':
               res = n1 * n2;
                break;
            case '/':
                res = n1 / n2;
                break;
            default:
              System.out.print("Error!Enter the correct operator!");
              return 0;
        }
     return 1;
    }
  }



