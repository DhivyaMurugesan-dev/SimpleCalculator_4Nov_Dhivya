package com.example.simplecalculator_4nov_dhivya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public abstract class MainActivity <onclick> extends AppCompatActivity implements View.OnClickListener {

    TextView textView;
    TextView resultview;
    //String tag = MainActivity;
    Calculate objcalc = new Calculate();
    //String tmptext = allbtn.getText().toString();
    //Record the user clicked operator
    String tmptext = "";
    Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btnadd, btnsub, btnmul, btnequal, btndiv, btnclear;
    int n1, n2;
    char op;
    // int add, sub, mul, div;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btn0 = (Button) findViewById(R.id.btn0);
        btnequal = (Button) findViewById(R.id.btnequal);
        btnadd = (Button) findViewById(R.id.btnadd);
        btnsub = (Button) findViewById(R.id.btnsub);
        btndiv = (Button) findViewById(R.id.btndiv);
        btnmul = (Button) findViewById(R.id.btnmul);
        btnclear = (Button) findViewById(R.id.btnclear);
        resultview = (TextView) findViewById(R.id.resultview);
        //resultview.setText("");
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);
        btnadd.setOnClickListener(this);
        btnsub.setOnClickListener(this);
        btnmul.setOnClickListener(this);
        btndiv.setOnClickListener(this);
        btnequal.setOnClickListener(this);
        btnclear.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        //If the view is equal to the button clicked
        if (view == btnequal) {
            //To calculate the numbers with operators
            int finalres = objcalc.splcalculate(n1,n2,op);
            } else {
            // Get the button text.
            Button allbtn = (Button) view;
            tmptext += allbtn.getText().toString();
            //Calling the push method with the help of the Calculate  object
            objcalc.push(tmptext);
            //Displays the result
            resultview.setText(tmptext);
            //Stores the value in the newtext
            String newtext = (String) resultview.getText();
          //  tmptext = tmptext.substring(0, tmptext.length() - 1);
            //resultview = tmptext + newtext;
        }
    }
}





